// 1) วาง Web app URL จาก Google Apps Script ในตัวแปรนี้ก่อนใช้งานจริง
const SHEET_API_URL = 'https://script.google.com/macros/s/AKfycbxWU254A2syh3hOrBOW0iUj4rGEDy34bOa5W7YxYFvsUBCzqjNircWhVOojedm_O4_d/exec';
const products = {
  SP001: { name: 'SmilePlus Cool Mint', price: 99 },
  SP002: { name: 'SmilePlus Herbal Care', price: 109 }
};
const cart = {};
function addToCart(sku){ cart[sku]=(cart[sku]||0)+1; renderCart(); }
function renderCart(){
  const keys=Object.keys(cart); const box=document.getElementById('cartItems');
  box.innerHTML=keys.length?keys.map(s=>`<div class="cart-line"><span>${products[s].name} × ${cart[s]}</span><b>฿${products[s].price*cart[s]}</b></div>`).join(''):'ยังไม่มีสินค้าในตะกร้า';
  document.getElementById('cartTotal').textContent='฿'+keys.reduce((sum,s)=>sum+products[s].price*cart[s],0);
}
document.getElementById('checkoutForm').addEventListener('submit',async e=>{
  e.preventDefault(); const keys=Object.keys(cart); const msg=document.getElementById('checkoutMessage');
  if(!keys.length){msg.textContent='กรุณาเลือกสินค้าก่อนยืนยันคำสั่งซื้อ';return;}
  const f=new FormData(e.target); const orderId='SP'+Date.now().toString().slice(-8);
  const order={orderId,createdAt:new Date().toLocaleString('th-TH'),customer:f.get('customer'),phone:f.get('phone'),postcode:f.get('postcode'),address:f.get('address'),items:keys.map(s=>({sku:s,name:products[s].name,qty:cart[s],price:products[s].price})),total:keys.reduce((n,s)=>n+cart[s]*products[s].price,0),status:'รอแพ็ก'};
  if(SHEET_API_URL.startsWith('https://')){
    try{await fetch(SHEET_API_URL,{method:'POST',mode:'no-cors',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(order)});msg.textContent='ส่งคำสั่งซื้อแล้ว กรุณาตรวจสอบรายการใน Google Sheets';}
    catch(err){msg.textContent='ส่งข้อมูลไม่สำเร็จ กรุณาตรวจสอบ URL หรืออินเทอร์เน็ต';return;}
  }else{msg.textContent='ตัวอย่างคำสั่งซื้อถูกสร้างแล้ว แต่ยังไม่ได้เชื่อม Google Sheets';}
  localStorage.setItem('smileplus-last-order',JSON.stringify(order)); Object.keys(cart).forEach(k=>delete cart[k]);renderCart();e.target.reset();
});
async function loadOrders(){
 const area=document.getElementById('ordersArea');
 if(!SHEET_API_URL.startsWith('https://')){area.textContent='ยังไม่ได้ตั้งค่า Google Apps Script URL ใน app.js';return;}
 area.textContent='กำลังโหลดข้อมูล...';
 try{const res=await fetch(SHEET_API_URL+'?action=list');const orders=await res.json();
  if(!orders.length){area.textContent='ยังไม่มีคำสั่งซื้อ';return;}
  area.innerHTML=orders.map(o=>`<article class="order-card"><h3>คำสั่งซื้อ ${escapeHtml(o.orderId)} <span class="status">${escapeHtml(o.status||'รอแพ็ก')}</span></h3><p>วันที่: ${escapeHtml(o.createdAt||'')}</p><p>ผู้รับ: ${escapeHtml(o.customer)} | โทร: ${escapeHtml(o.phone)}</p><p>ที่อยู่: ${escapeHtml(o.address)} ${escapeHtml(o.postcode)}</p><h4>รายการหยิบสินค้า (Picking List)</h4><table><tr><th>SKU</th><th>สินค้า</th><th>จำนวน</th><th>ราคา</th></tr>${(o.items||[]).map(i=>`<tr><td>${escapeHtml(i.sku)}</td><td>${escapeHtml(i.name)}</td><td>${i.qty}</td><td>฿${i.price*i.qty}</td></tr>`).join('')}</table><b>ยอดรวม ฿${o.total}</b><div class="print-label"><b>ใบจ่าหน้าพัสดุ / SHIPPING LABEL</b><p>ผู้รับ: ${escapeHtml(o.customer)}</p><p>โทร: ${escapeHtml(o.phone)}</p><p>ที่อยู่: ${escapeHtml(o.address)} ${escapeHtml(o.postcode)}</p><p>เลขที่คำสั่งซื้อ: ${escapeHtml(o.orderId)}</p></div><button class="outline" onclick="window.print()">พิมพ์ใบหยิบสินค้าและใบจ่าหน้า</button></article>`).join('');
 }catch(err){area.textContent='โหลดข้อมูลไม่ได้ กรุณาตรวจสอบการ Deploy Apps Script และสิทธิ์การเข้าถึง';}
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
