// Google Sheets > Extensions > Apps Script แล้ววางโค้ดนี้
const SHEET_NAME = 'Orders';
const HEADERS = ['orderId','createdAt','customer','phone','postcode','address','sku','product','qty','unitPrice','lineTotal','orderTotal','status'];
function getSheet(){
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  let sh=ss.getSheetByName(SHEET_NAME);
  if(!sh) sh=ss.insertSheet(SHEET_NAME);
  if(sh.getLastRow()===0) sh.appendRow(HEADERS);
  return sh;
}
function doPost(e){
  const order=JSON.parse(e.postData.contents); const sh=getSheet();
  order.items.forEach(item=>sh.appendRow([order.orderId,order.createdAt,order.customer,order.phone,order.postcode,order.address,item.sku,item.name,item.qty,item.price,item.qty*item.price,order.total,order.status]));
  return ContentService.createTextOutput(JSON.stringify({ok:true,orderId:order.orderId})).setMimeType(ContentService.MimeType.JSON);
}
function doGet(e){
  const sh=getSheet(); const values=sh.getDataRange().getValues();
  if(values.length<2)return ContentService.createTextOutput('[]').setMimeType(ContentService.MimeType.JSON);
  const rows=values.slice(1); const grouped={};
  rows.forEach(r=>{const id=String(r[0]);if(!grouped[id])grouped[id]={orderId:id,createdAt:r[1],customer:r[2],phone:r[3],postcode:r[4],address:r[5],items:[],total:Number(r[11]),status:r[12]};grouped[id].items.push({sku:r[6],name:r[7],qty:Number(r[8]),price:Number(r[9])});});
  return ContentService.createTextOutput(JSON.stringify(Object.values(grouped).reverse())).setMimeType(ContentService.MimeType.JSON);
}
