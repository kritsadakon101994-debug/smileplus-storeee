# SmilePlus toothpaste store

## ไฟล์ในโปรเจกต์
- `index.html` หน้า Landing Page และแบบฟอร์มสั่งซื้อ
- `style.css` รูปแบบเว็บไซต์
- `app.js` ตะกร้าสินค้า ส่งออเดอร์ และหน้าหยิบ/แพ็ก/พิมพ์ใบจ่าหน้า
- `google-apps-script.gs` ตัวกลางเชื่อม Google Sheets
- `images/` โฟลเดอร์เก็บรูปสินค้าแยกต่างหาก

## 1) เตรียม Google Sheets
1. สร้าง Google Sheet ชื่อ `SmilePlus Orders`
2. เปิด Extensions > Apps Script
3. วางโค้ดจาก `google-apps-script.gs` แล้ว Save
4. กด Deploy > New deployment > เลือก Web app
5. Execute as: Me และ Who has access: Anyone (ใช้สำหรับงานสาธิตในชั้นเรียน)
6. กด Deploy และคัดลอก Web app URL
7. เปิด `app.js` แล้วแทน `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE` ด้วย URL ที่คัดลอก

## 2) ทดสอบในเครื่อง
เปิด `index.html` ผ่าน Live Server ใน VS Code (แนะนำ) หรือเปิดไฟล์ตรง ๆ เพื่อดูหน้าร้าน
ลองเพิ่มสินค้า กรอกข้อมูลลูกค้า และยืนยันคำสั่งซื้อ จากนั้นกดโหลดออเดอร์ในส่วนจัดการออเดอร์

## 3) ฝาก GitHub
1. สร้าง Repository ใหม่ เช่น `smileplus-toothpaste`
2. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมด โดยคงโฟลเดอร์ `images` ไว้
3. Commit changes

## 4) Deploy Vercel
1. เข้า Vercel แล้วเลือก Add New > Project
2. Import Git Repository ที่สร้างไว้
3. Framework Preset เลือก Other; Build Command และ Output Directory เว้นว่าง
4. กด Deploy แล้วเปิดโดเมนที่ Vercel ให้มา

## ข้อควรทราบ
โครงงานนี้เป็นต้นแบบเพื่อการเรียนรู้ ไม่ใช่ระบบขนส่งจริง ใบจ่าหน้าเป็นข้อมูลที่พิมพ์จากคำสั่งซื้อ ไม่ได้สร้างเลข Tracking หรือเรียก API บริษัทขนส่งจริง และ Web App ที่เปิด Anyone ไม่ควรใช้เก็บข้อมูลลูกค้าจริงโดยไม่มีระบบยืนยันตัวตน/ป้องกันข้อมูลส่วนบุคคล
